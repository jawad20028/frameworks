package be.ehb.derdehands;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DerdehandsApplicationTests {

    @Test
    void contextLoads() {
    }

}
